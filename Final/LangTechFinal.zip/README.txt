# Language Technology: Final Project #

_______________________________________

Group: Kanye West

Members:

Nathan Bosch (s3475344)
Jeongu Kim   (s2894742)
KJR Sabandar (s2864819)
Daan Windt   (s3486429)


Usage:

Run as: py mainQA.py

Type in your question (id optional) and get a result.

(e.g.
    >>Is Donda West the mother of Kanye West?
    >>Yes
)

If there is a questions file add it as the first argument:

py mainQA.py questions.txt

It has to be a txt file. In the format:

id\tquestion

where id is an integer, \t is a tab, and the question is a string.
